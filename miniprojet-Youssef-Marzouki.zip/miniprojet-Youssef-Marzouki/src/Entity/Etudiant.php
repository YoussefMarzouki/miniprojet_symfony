<?php

namespace App\Entity;

use App\Repository\EtudiantRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EtudiantRepository::class)]
class Etudiant
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 15)]
    private ?string $etud_id = null;

    #[ORM\Column(length: 20)]
    private ?string $nom_et = null;

    #[ORM\ManyToOne(inversedBy: 'etudiants')]
    #[ORM\JoinColumn(nullable: false)]
    private ?Institut $instit = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtudId(): ?string
    {
        return $this->etud_id;
    }

    public function setEtudId(string $etud_id): static
    {
        $this->etud_id = $etud_id;

        return $this;
    }

    public function getNomEt(): ?string
    {
        return $this->nom_et;
    }

    public function setNomEt(string $nom_et): static
    {
        $this->nom_et = $nom_et;

        return $this;
    }

    public function getInstit(): ?Institut
    {
        return $this->instit;
    }

    public function setInstit(?Institut $instit): static
    {
        $this->instit = $instit;

        return $this;
    }
}
